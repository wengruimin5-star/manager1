# 台股筆記｜GitHub Pages 部署

此壓縮檔已包含可直接部署的靜態網站檔案。

部署方式：
1. 解壓縮此 ZIP。
2. 將解壓縮後的 index.html、assets/ 與 manus-routes.json 放到 GitHub Pages 的發布來源根目錄。
3. 在 GitHub repository 的 Settings → Pages 選擇該分支與根目錄。
